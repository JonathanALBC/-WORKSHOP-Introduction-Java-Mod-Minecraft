package com.example.examplemod.item;

import com.example.examplemod.ExampleMod;
import net.minecraft.block.Block;
import net.minecraft.item.Item;

import java.util.ArrayList;

public class ModidItems {
    public static final ArrayList <Item> ITEMS = new ArrayList<>();

    public static void setItemName(Item item, String name) {
        item.setRegistryName(ExampleMod.MODID, name).setUnlocalizedName(ExampleMod.MODID + "." + name);
        ITEMS.add(item);
    }

    public static void setItemBlockName(Item item, Block block) {
        item.setRegistryName(block.getRegistryName());
        ITEMS.add(item);
    }
}

