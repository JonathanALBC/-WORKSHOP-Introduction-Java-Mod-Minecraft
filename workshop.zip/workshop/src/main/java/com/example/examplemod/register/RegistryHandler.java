package com.example.examplemod.register;

public class RegistryHandler {
}
